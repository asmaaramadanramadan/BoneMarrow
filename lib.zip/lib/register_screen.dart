import 'package:flutter/material.dart';
class RegistScreen extends StatefulWidget {
  @override
  State<RegistScreen> createState() => _RegistScreenState();
}
class _RegistScreenState extends State<RegistScreen> {
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              "Registration",
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 35,
              ),
            ),
            SizedBox(
              height: 20,
            ),
            Row(mainAxisAlignment: MainAxisAlignment.center, children: [
              Container(
                decoration: BoxDecoration(color: Colors.blue,
                ),
                child: TextButton(
                  onPressed: () {},
                  child: Text(
                    "AS a Doctor",
                    style: TextStyle(
                        color: Colors.white
                      //fontWeight: FontWeight.bold,
                      //fontSize: 35,
                    ),
                  ),
                ),
              ),
              SizedBox(
                width: 20,
              ),
              Container(
                decoration: BoxDecoration(color: Colors.blue,
                ),
                child: TextButton(
                  onPressed: () {},
                  child: Text(
                    "AS a Patient",
                    style: TextStyle(
                      color: Colors.white
                      //fontWeight: FontWeight.bold,
                      //fontSize: 35,
                    ),
                  ),
                ),
              ),
            ]),
          ],
        ),
      ),
    );
  }
}
