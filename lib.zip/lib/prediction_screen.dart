//import 'dart:html';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';



class Prediction extends StatefulWidget {
  const Prediction({Key? key}) : super(key: key);

  @override
  State<Prediction> createState() => _PredictionState();
}



//final ImagePicker _picker = ImagePicker();

class _PredictionState extends State<Prediction> {

  final ImagePicker _picker = ImagePicker();
  File? pickedImage;

  fitchImage() async {
    final XFile? image = await _picker.pickImage(
        source: ImageSource.gallery);
    if (image == null) {
      return;
    }
      setState(() {
        pickedImage = File(image.path,);
      });
    }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(),
      body: Center(
        child: Column(
          children: [
            Container(
              child:pickedImage == null? null: Image.file(pickedImage!) ,
            ),
            SizedBox(height: 10,),
            MaterialButton(
                minWidth: 30.0,
                color: Colors.teal,
                shape: RoundedRectangleBorder(
                    side: BorderSide(color: Colors.white),
                    borderRadius: BorderRadius.circular(15.0)),
                onPressed: fitchImage,
                child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Text(
                    "Upload Image",
                    style: TextStyle(color: Colors.white),
                  ),
                )),
          ],
        ),

      ),
    );
  }
}
