import 'package:flutter/material.dart';
import 'package:g_project/widget/fields.dart';

class DoctorRegist extends StatefulWidget {
  const DoctorRegist({Key? key}) : super(key: key);

  @override
  State<DoctorRegist> createState() => _DoctorRegistState();
}

class _DoctorRegistState extends State<DoctorRegist> {

  String bText = "Sign Up";
  bool lSwitch = false;
  GlobalKey<FormState>_key = GlobalKey<FormState>();
   final _key1 = GlobalKey<FormState>();
  var _namecontroller = TextEditingController();

  bool  passvisible = true;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(),
      body: Padding(
        padding: const EdgeInsets.all(18.0),
        child: Center(
          child: SingleChildScrollView(
            child: Column(
              children: [
                Text("Welcome Doctor"),
                SizedBox(height: 15,),
                lSwitch?signUP(): signIn(),
               // signUP(),
                    lSwitch? Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                      Text(
                        "Have an account ?",
                      ),
                      TextButton(
                        onPressed: () {
                          setState(() {
                            lSwitch=!lSwitch;
                          });
                        },
                        child: Text("Login"),
                      ),
                    ]):
                    Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                      Text(
                        "Don\'t an account ?",
                      ),
                      TextButton(
                        onPressed: () {
                          setState(() {
                            lSwitch=!lSwitch;
                          });
                        },
                        child: Text("Sign UP"),
                      ),
                    ]),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Form signUP() {
    return Form(
              key: _key,
              child: Container(
                margin: EdgeInsets.symmetric(
                  horizontal: 10,
                ),
                child:Column(
                  children: [
                    defultTextFied(
                      hint: "enter your name",
                      label: "Name",
                      type: TextInputType.text,
                      pIcon: Icon(Icons.person),
                      onSave: () => (String? val) {
                        setState(() {});
                      },
                      validate: () => (String? val) {
                        if (val!.isEmpty) {
                          return "this field can't be empty";
                        }
                      },
                      vall: false,
                    ),
                    SizedBox(
                      height: 15,
                    ),
                    defultTextFied(
                      hint: "enter your Phone",
                      label: "Phone",
                      type: TextInputType.number,
                      pIcon: Icon(Icons.phone),
                      onSave: () => (String? val) {
                        setState(() {});
                      },
                      validate: () => (String? val) {
                        if (val!.isEmpty) {
                          return "this field can't be empty";
                        }
                      },
                      vall: false,
                    ),
                    SizedBox(height: 15,),
                    defultTextFied(
                      hint: "enter your Email",
                      label: "Email",
                      type: TextInputType.emailAddress,
                      pIcon: Icon(Icons.email),
                      onSave: () => (String? val) {
                        setState(() {});
                      },
                      validate: () => (String? val) {
                        if (val!.isEmpty) {
                          return "this field can't be empty";
                        }
                      },
                      vall: false,
                    ),
                    SizedBox(height: 15,),
                    defultTextFied(
                      hint: "Enter Password",
                      label: "Password",
                      type: TextInputType.emailAddress,
                      pIcon: Icon(Icons.lock),
                      sIcon: IconButton(
                        icon: Icon(
                          passvisible ? Icons.visibility : Icons.visibility_off,
                        ),
                        onPressed: () {
                          setState(() {
                            passvisible = !passvisible;
                          });
                        },
                      ),
                      onSave: () => (String? val) {
                        setState(() {});
                      },
                      validate: () => (String? val) {
                        if (val!.isEmpty) {
                          return "this field can't be empty";
                        }
                      },
                      vall: false,
                    ),
                    SizedBox(height: 15,),
                    defultTextFied(
                      hint: "enter your info",
                      label: "Bio",
                      type: TextInputType.text,
                      pIcon: Icon(Icons.edit),
                      onSave: () => (String? val) {
                        setState(() {});
                      },
                      validate: () => (String? val) {
                        if (val!.isEmpty) {
                          return "this field can't be empty";
                        }
                      },
                      vall: false,
                    ),
                    TextButton(
                      onPressed: (){},
                        child:Text("Sign Up"),),
                  ],
                ),
              ),
            );
  }
  Form signIn() {
    return Form(
      key: _key1,
      child: Container(
        margin: EdgeInsets.symmetric(
          horizontal: 10,
        ),
        child:Column(
          children: [
            SizedBox(height: 15,),
            defultTextFied(
              hint: "enter your Email",
              label: "Email",
              type: TextInputType.emailAddress,
              pIcon: Icon(Icons.email),
              onSave: () => (String? val) {
                setState(() {});
              },
              validate: () => (String? val) {
                if (val!.isEmpty) {
                  return "this field can't be empty";
                }
              },
              vall: false,
            ),
            SizedBox(height: 15,),
            defultTextFied(
              hint: "Enter Password",
              label: "Password",
              type: TextInputType.visiblePassword,
              pIcon: Icon(Icons.lock),
              sIcon: IconButton(
                icon: Icon(
                  passvisible ? Icons.visibility : Icons.visibility_off,
                ),
                onPressed: () {
                  setState(() {
                    passvisible = !passvisible;
                  });
                },
              ),
              onSave: () => (String? val) {
                setState(() {});
              },
              validate: () => (String? val) {
                if (val!.isEmpty) {
                  return "this field can't be empty";
                }
              },
              vall: passvisible,
            ),
            TextButton(
              onPressed: (){},
              child:Text("Sign in"),),
          ],
        ),
      ),
    );
  }
}
