import 'package:flutter/material.dart';
class defultTextFied extends StatelessWidget {
  String? hint;
  String? label;
  Widget? pIcon;
  Widget? sIcon;
  TextInputType? type;
  // required Function() onTab,
  Function()? validate;
  Function()? onSave;
  bool? vall = false;
  defultTextFied({
    this.hint,
    this.label,
    this.onSave,
    this.pIcon,
    this.sIcon,
    this.type,
    this.validate,
    this.vall,
  });
  @override
  Widget build(BuildContext context) {
    return TextFormField(
      keyboardType: type,
      validator: validate!(),
      onSaved: onSave!(),
      // keyboardType: TextInputType.visiblePassword,
        obscureText: vall!,
        decoration: InputDecoration(
        labelText: label,
        labelStyle: TextStyle(
          fontSize: 20,
          color: Colors.grey[700],
        ),
        hintText: hint,
        hintStyle: TextStyle(
          fontSize: 19,
          color: Colors.grey[700],
        ),
        border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(25),
            borderSide: const BorderSide(color: Colors.black, width: 1.2)),
        enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(25),
            borderSide: const BorderSide(color: Colors.black, width: 1.2)),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(25),
          borderSide: const BorderSide(color: Colors.black, width: 1.2),
        ),
        filled: true,
        fillColor: Colors.white,
        prefixIcon: pIcon,
          suffixIcon:sIcon,

      ),
    );
  }
}