import 'package:flutter/material.dart';
class Login_Screen extends StatefulWidget {
  const Login_Screen({Key? key}) : super(key: key);
  @override
  State<Login_Screen> createState() => _Login_ScreenState();
}
class _Login_ScreenState extends State<Login_Screen> {
  var emailcontroller = TextEditingController();
  var passwordcontroller = TextEditingController();
  var passvisible = true;
  @override
  Widget build(BuildContext context) {
    return  Scaffold(
      appBar: AppBar(),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Center(
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Login',
                  style: TextStyle(
                    fontSize: 40.0,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                SizedBox(
                  height: 10,
                ),
                Container(
                  child: TextFormField(
                    controller: emailcontroller,
                    decoration: InputDecoration(
                      prefixIcon: Icon(Icons.email),
                      border: OutlineInputBorder(),
                      labelText: 'enterb your email',
                      labelStyle: TextStyle(),
                    ),
                    keyboardType: TextInputType.visiblePassword,
                    onFieldSubmitted: (String value) {
                      print(value);
                    },
                    onChanged: (value) {
                      print(value);
                    },
                  ),
                ),
                SizedBox(
                  height: 15,
                ),
                Container(
                  child: TextFormField(
                    obscureText: passvisible,
                    controller: passwordcontroller,
                    decoration: InputDecoration(
                      // prefixIcon: Icon(Icons.lock),
                      suffixIcon: IconButton(
                        icon: Icon(
                          passvisible ? Icons.visibility : Icons.visibility_off,
                        ),
                        onPressed: () {
                          setState(() {
                            passvisible = !passvisible;
                          });
                        },
                      ),
                      border: OutlineInputBorder(),
                      labelText: 'enterb your passwoed',
                      labelStyle: TextStyle(),
                    ),
                    keyboardType: TextInputType.number,
                    onFieldSubmitted: (String value) {
                      print(value);
                    },
                    onChanged: (value) {
                      print(value);
                    },
                  ),
                ),
                SizedBox(
                  height: 15,
                ),
                Container(
                  width: double.infinity,
                  height: 30.0,
                  child: MaterialButton(
                    color: Colors.blue,
                    onPressed: () {
                      print(emailcontroller.text);
                      print(passwordcontroller.text);
                    },
                    child: Text("BOGIN",
                        style: TextStyle(
                          color: Colors.white,
                        )),
                  ),
                ),
                SizedBox(
                  height: 25.0,
                ),
                Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                  Text(
                    "Don\'t an account ?",
                  ),
                  TextButton(
                    onPressed: () {},
                    child: Text("Register Now"),
                  ),
                ])
              ],
            ),
          ),
        ),
      ),
    );
  }
}
