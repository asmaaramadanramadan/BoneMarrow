import 'package:flutter/material.dart';
import 'package:easy_splash_screen/easy_splash_screen.dart';
class splashScreen extends StatefulWidget {
  const splashScreen({Key? key}) : super(key: key);

  @override
  State<splashScreen> createState() => _splashScreenState();
}

class _splashScreenState extends State<splashScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body:EasySplashScreen(
        backgroundColor:Colors.blueAccent,
        logo:Image.asset("assets/images/s1.jpg"),
        title: Text("title "),
        logoWidth:290,
        showLoader:true,
        //navigator: myPage2 (),
        durationInSeconds:10,
      ),
    );
  }
}
